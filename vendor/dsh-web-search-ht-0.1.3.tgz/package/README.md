# dsh-web-search-ht

把 **DeepSeek Harness（DSH）** 的联网搜索能力（`ctx.web` seam）接到华泰内网 AI 服务的
Web 搜索接口：

```
POST http://168.63.65.40:8090/ai-service/v1/api/web/search
```

装上并启用后，DSH 里所有走"网页搜索"的功能（Agent 的 web_search 工具、聊天里的联网检索等）
都会改用这个内网接口，而不是公网搜索引擎。

## 特性

- 标准 `ctx.web.registerSearchProvider` Provider，id 为 `ht-web-search`
- **内置公共 apiKey 默认值**：`001614@0a63a2b250124d19bbd3d66e21b57ae1`，开箱即用；每个用户可在设置页改用自己的 key
- apiKey 三级回退：设置页字面值 → credentials 服务引用 → 启动环境变量
- 支持 **HTSC AI provider 密钥**（按使用人记账）：请求头 `x-user-apikey` **总是发送**——优先取设置页 `userApiKey` → DSH credentials `HTSCAI_API_KEY`（Models 页配的 HTSC AI key，每用户独立）→ 环境变量 `HT_WEB_SEARCH_USER_API_KEY` → 空字符串
- 透传上游能力：行业搜索（finance/videogame）、权威度过滤、时间范围、限定/屏蔽域名、精准摘要
- 已适配实测的真实响应（小写字段名）和网关错误包装（`{code:802}` 鉴权失败、`{code:500}` 参数错误）

## 安装（本地 profile 插件）

这是 DSH **profile 级**插件，不修改 DSH 桌面本体，升级安全。

### 1. 把包放进 profile

找到你的 DSH 用户目录（桌面端一般类似）：

```
Windows:  %APPDATA%\dsh\profiles\desktop        （或 %USERPROFILE%\.dsh\profiles\desktop）
macOS:    ~/Library/Application Support/dsh/profiles/desktop
Linux:    ~/.config/dsh/profiles/desktop
```

把整个 `dsh-web-search-ht` 目录复制到该 profile 的 `node_modules` 下，
或在该 profile 目录用相对路径安装：

```bash
cd <profile 目录>
pnpm add <本仓库路径>/plugins/dsh-web-search-ht
```

### 2. 在 profile 声明 bundle

编辑 profile 目录下的 `package.json`，把包名加进 `dsh.profile.bundles`：

```json
{
  "dsh": {
    "profile": {
      "bundles": ["dsh-web-search-ht"]
    }
  }
}
```

### 3. 选它为搜索 Provider

二选一：

- 在 DSH **设置 → Web → Search Provider** 里选 `ht-web-search`；或
- 设环境变量 `DSH_WEB_SEARCH_PROVIDER=ht-web-search`

> 注意：如果没显式指定，而系统里同时存在多个可用搜索 Provider，web seam 会报
> `WEB_PROVIDER_AMBIGUOUS`。指定 `ht-web-search` 即可消除歧义。

### 4. 重启 DSH

## 每用户填自己的 apiKey

启用后，到 **设置 → Web Search (HT)** 这一节：

| 字段 | 说明 |
|---|---|
| **apiKey** | 华泰 AI 服务 apiKey，格式 `appId@xxx`。**默认公共 key** `001614@0a63a2b250124d19bbd3d66e21b57ae1`，开箱即用；可改为自己的 key（测试环境找朱建新 022287 申请，生产走 2.1 流程） |
| apiKeyEnv | 高级：改为环境变量引用名（默认 `HT_WEB_SEARCH_API_KEY`）。设置了该环境变量时可覆盖默认 key |
| **userApiKey** | HTSC AI provider 密钥（按使用人记账）。写入请求头 `x-user-apikey`（总是发送）。取值优先级：设置页字面值 → DSH credentials `HTSCAI_API_KEY`（即 Models 页配的 HTSC AI key）→ 环境变量 `HT_WEB_SEARCH_USER_API_KEY` → 空字符串 |
| baseURL | 网关地址，默认 `http://168.63.65.40:8090`（测试）；生产换 host 即可 |
| baseURL | 网关地址，默认 `http://168.63.65.40:8090`（测试）；生产换 host 即可 |
| defaultCount | 默认返回条数，≤50 |
| industry | `finance` / `videogame`（仅测试环境），留空为通用搜索 |
| timeRange | `OneDay`/`OneWeek`/`OneMonth`/`OneYear` 或 `YYYY-MM-DD..YYYY-MM-DD`，留空不限 |
| authInfoLevel | `0` 不限 / `1` 只要非常权威来源 |
| needSummary | 是否返回 300~500 字模型精准摘要（更耗 token、更慢） |
| sites | 限定域名，`\|` 分隔，≤5 个完整域名，如 `eastmoney.com\|sse.com.cn` |
| blockHosts | 屏蔽域名，`\|` 分隔 |
| needContent / needUrl | 仅返回有正文 / 有原文链接的结果 |

**金融场景推荐组合**：`industry=finance` + `authInfoLevel=1` + 按需 `timeRange`，
召回基本全是中证网/证券时报/经济观察网这类权威财经源。

## 错误处理对照

| 现象 | 含义 | 处理 |
|---|---|---|
| `WEB_PROVIDER_CREDENTIAL_MISSING` | 没填 key 或 key 无权限（上游 `code:802`） | 在设置页填有效 apiKey，或确认已开通搜索服务 |
| `WEB_PROVIDER_ERROR`（业务错误 10400） | 参数错误 | 一般是 Query 为空或字段类型问题 |
| `WEB_PROVIDER_AMBIGUOUS` | 多个搜索 Provider 可用但未指定 | 设置里显式选 `ht-web-search` |
| `WEB_ABORTED` | 调用方取消 | 正常，无需处理 |

## 与上游接口的差异（实现已适配）

实测该接口与官方文档有两处出入，本插件已兼容：

1. **响应字段名是小写**（`result`/`webResults`/`originQuery`），非文档的大写
2. **业务/鉴权错误走网关包装** `{code, msg, data}`，且 **HTTP 恒为 200**，不能靠状态码判成败

## 开发

```bash
# 语法校验
node --check lib/index.js
```

结构对齐官方 `@deepseek-ai/dsh-web-search-deepseek`，可作为二次开发参考。
